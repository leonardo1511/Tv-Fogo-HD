import xbmcaddon

MainBase = 'https://goo.gl/vmKktY'
addon = xbmcaddon.Addon('plugin.video.tvfogohd')
